#These two lists help in getting coordinates of the adjacent 4 cells
rowNums = [0, -1, 0, 1]
colNums = [-1, 0, 1, 0]

class Point():

    # Objects of this class would be used to define coordinates in the matrix

    def __init__(self, x, y):
        self.x = x
        self.y = y

class Node():

    #Objects of this class would be used to define every entry in the matrix
    #including it's coordinates and distance from source

    def __init__(self, coordinates, dist):
        self.coordinates = coordinates
        self.dist = dist

def isSafe(x, y, nrow, ncol):

    #This method would help to evaluate if a pair of coordinates is valid or not

    if x >= 0 and x < nrow and y >= 0 and y < ncol:
        return True
    return False


def shortestPathInAMaze(maze, src, dest):

    nrow = len(maze)
    ncol = len(maze[0])

    val = DFS(maze, src, dest, nrow, ncol)

    return val


def DFS(maze, src, dest, nrow, ncol):

    visited = []

    # if src or destination is an obstacle, we cannot have a path
    if maze[src.x][src.y] != 1 or maze[dest.x][dest.y] != 1:
        return -1

    for i in range(len(maze)):
        visited.append([False] * len(maze[i]))

    #Mark the source as visited
    visited[src.x][src.y] = True

    stack = []*(nrow*ncol)

    #Add source to stack
    stack.append(Node(src, 0))

    while not len(stack) == 0:
        current = stack.pop()

        point = current.coordinates

        #If coordinates of current node are same as destination, the goal has been reached
        if point.x == dest.x and point.y == dest.y:
            return current.dist

        for i in range(0, 4):
            row = point.x + rowNums[i]
            col = point.y + colNums[i]

            #add the adjacent node to queue if it is a valid coordinate, it is not an obstacle and has not been visited yet
            if isSafe(row, col, nrow, ncol) and maze[row][col] != 0 and visited[row][col] is False:
                visited[row][col] = True
                newNode = Node(Point(row, col), current.dist + 1)
                stack.append(newNode)

    #If a path has not been found then return -1
    return -1


if __name__ == "__main__":

    inputMaze = [[1, 0, 0, 0],
                 [1, 1, 0, 1],
                 [0, 1, 0, 0],
                 [1, 1, 1, 1]]

    src  = [0, 0]
    dest = [3, 3]

    srcObject = Point(src[0], src[1])
    destObject = Point(dest[0], dest[1])

    val = shortestPathInAMaze(inputMaze, srcObject, destObject)

    if val == -1:
        print("Path does not exist")
    else:
        print("Length of shortest path is: ", val)
